function Check(){
    // alert('check');
}

function Contribution(){
    // alert('Contribution');
}
function Survey(){
    // alert('Survey');
}
function Logout(){
    // alert('Logout');
}